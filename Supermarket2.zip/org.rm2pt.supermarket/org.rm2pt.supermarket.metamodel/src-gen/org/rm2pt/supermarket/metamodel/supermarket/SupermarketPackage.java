/**
 */
package org.rm2pt.supermarket.metamodel.supermarket;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketFactory
 * @model kind="package"
 * @generated
 */
public interface SupermarketPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "supermarket";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/supermarket";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "supermarket";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SupermarketPackage eINSTANCE = org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.ProductImpl <em>Product</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.ProductImpl
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getProduct()
	 * @generated
	 */
	int PRODUCT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__PRICE = 1;

	/**
	 * The feature id for the '<em><b>Product Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT__PRODUCT_CODE = 2;

	/**
	 * The number of structural features of the '<em>Product</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Product</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRODUCT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl <em>Sales Transaction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getSalesTransaction()
	 * @generated
	 */
	int SALES_TRANSACTION = 1;

	/**
	 * The feature id for the '<em><b>Transaction ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION__TRANSACTION_ID = 0;

	/**
	 * The feature id for the '<em><b>Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION__DATE = 1;

	/**
	 * The feature id for the '<em><b>Total Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION__TOTAL_AMOUNT = 2;

	/**
	 * The feature id for the '<em><b>Product</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION__PRODUCT = 3;

	/**
	 * The feature id for the '<em><b>Customer</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION__CUSTOMER = 4;

	/**
	 * The feature id for the '<em><b>Payment</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION__PAYMENT = 5;

	/**
	 * The number of structural features of the '<em>Sales Transaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Sales Transaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SALES_TRANSACTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.CustomerImpl <em>Customer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.CustomerImpl
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getCustomer()
	 * @generated
	 */
	int CUSTOMER = 2;

	/**
	 * The feature id for the '<em><b>Customer ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__CUSTOMER_ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__NAME = 1;

	/**
	 * The feature id for the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__EMAIL = 2;

	/**
	 * The feature id for the '<em><b>Salestransaction</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__SALESTRANSACTION = 3;

	/**
	 * The number of structural features of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl <em>Payment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl
	 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getPayment()
	 * @generated
	 */
	int PAYMENT = 3;

	/**
	 * The feature id for the '<em><b>Payment ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT__PAYMENT_ID = 0;

	/**
	 * The feature id for the '<em><b>Payment Method</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT__PAYMENT_METHOD = 1;

	/**
	 * The feature id for the '<em><b>Amount Paid</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT__AMOUNT_PAID = 2;

	/**
	 * The feature id for the '<em><b>Salestransaction</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT__SALESTRANSACTION = 3;

	/**
	 * The number of structural features of the '<em>Payment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Payment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link org.rm2pt.supermarket.metamodel.supermarket.Product <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Product</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Product
	 * @generated
	 */
	EClass getProduct();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Product#getName()
	 * @see #getProduct()
	 * @generated
	 */
	EAttribute getProduct_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Product#getPrice()
	 * @see #getProduct()
	 * @generated
	 */
	EAttribute getProduct_Price();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getProductCode <em>Product Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Product Code</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Product#getProductCode()
	 * @see #getProduct()
	 * @generated
	 */
	EAttribute getProduct_ProductCode();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction <em>Sales Transaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sales Transaction</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction
	 * @generated
	 */
	EClass getSalesTransaction();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTransactionID <em>Transaction ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transaction ID</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTransactionID()
	 * @see #getSalesTransaction()
	 * @generated
	 */
	EAttribute getSalesTransaction_TransactionID();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getDate <em>Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Date</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getDate()
	 * @see #getSalesTransaction()
	 * @generated
	 */
	EAttribute getSalesTransaction_Date();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTotalAmount <em>Total Amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Amount</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTotalAmount()
	 * @see #getSalesTransaction()
	 * @generated
	 */
	EAttribute getSalesTransaction_TotalAmount();

	/**
	 * Returns the meta object for the reference list '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getProduct <em>Product</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Product</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getProduct()
	 * @see #getSalesTransaction()
	 * @generated
	 */
	EReference getSalesTransaction_Product();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Customer</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getCustomer()
	 * @see #getSalesTransaction()
	 * @generated
	 */
	EReference getSalesTransaction_Customer();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getPayment <em>Payment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Payment</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getPayment()
	 * @see #getSalesTransaction()
	 * @generated
	 */
	EReference getSalesTransaction_Payment();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Customer</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Customer
	 * @generated
	 */
	EClass getCustomer();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getCustomerID <em>Customer ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Customer ID</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Customer#getCustomerID()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_CustomerID();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Customer#getName()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getEmail <em>Email</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Email</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Customer#getEmail()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_Email();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getSalestransaction <em>Salestransaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Salestransaction</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Customer#getSalestransaction()
	 * @see #getCustomer()
	 * @generated
	 */
	EReference getCustomer_Salestransaction();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment <em>Payment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Payment</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Payment
	 * @generated
	 */
	EClass getPayment();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentID <em>Payment ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Payment ID</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentID()
	 * @see #getPayment()
	 * @generated
	 */
	EAttribute getPayment_PaymentID();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentMethod <em>Payment Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Payment Method</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentMethod()
	 * @see #getPayment()
	 * @generated
	 */
	EAttribute getPayment_PaymentMethod();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getAmountPaid <em>Amount Paid</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Amount Paid</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Payment#getAmountPaid()
	 * @see #getPayment()
	 * @generated
	 */
	EAttribute getPayment_AmountPaid();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getSalestransaction <em>Salestransaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Salestransaction</em>'.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Payment#getSalestransaction()
	 * @see #getPayment()
	 * @generated
	 */
	EReference getPayment_Salestransaction();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SupermarketFactory getSupermarketFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.ProductImpl <em>Product</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.ProductImpl
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getProduct()
		 * @generated
		 */
		EClass PRODUCT = eINSTANCE.getProduct();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT__NAME = eINSTANCE.getProduct_Name();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT__PRICE = eINSTANCE.getProduct_Price();

		/**
		 * The meta object literal for the '<em><b>Product Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRODUCT__PRODUCT_CODE = eINSTANCE.getProduct_ProductCode();

		/**
		 * The meta object literal for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl <em>Sales Transaction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getSalesTransaction()
		 * @generated
		 */
		EClass SALES_TRANSACTION = eINSTANCE.getSalesTransaction();

		/**
		 * The meta object literal for the '<em><b>Transaction ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SALES_TRANSACTION__TRANSACTION_ID = eINSTANCE.getSalesTransaction_TransactionID();

		/**
		 * The meta object literal for the '<em><b>Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SALES_TRANSACTION__DATE = eINSTANCE.getSalesTransaction_Date();

		/**
		 * The meta object literal for the '<em><b>Total Amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SALES_TRANSACTION__TOTAL_AMOUNT = eINSTANCE.getSalesTransaction_TotalAmount();

		/**
		 * The meta object literal for the '<em><b>Product</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SALES_TRANSACTION__PRODUCT = eINSTANCE.getSalesTransaction_Product();

		/**
		 * The meta object literal for the '<em><b>Customer</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SALES_TRANSACTION__CUSTOMER = eINSTANCE.getSalesTransaction_Customer();

		/**
		 * The meta object literal for the '<em><b>Payment</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SALES_TRANSACTION__PAYMENT = eINSTANCE.getSalesTransaction_Payment();

		/**
		 * The meta object literal for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.CustomerImpl <em>Customer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.CustomerImpl
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getCustomer()
		 * @generated
		 */
		EClass CUSTOMER = eINSTANCE.getCustomer();

		/**
		 * The meta object literal for the '<em><b>Customer ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__CUSTOMER_ID = eINSTANCE.getCustomer_CustomerID();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__NAME = eINSTANCE.getCustomer_Name();

		/**
		 * The meta object literal for the '<em><b>Email</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__EMAIL = eINSTANCE.getCustomer_Email();

		/**
		 * The meta object literal for the '<em><b>Salestransaction</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUSTOMER__SALESTRANSACTION = eINSTANCE.getCustomer_Salestransaction();

		/**
		 * The meta object literal for the '{@link org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl <em>Payment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl
		 * @see org.rm2pt.supermarket.metamodel.supermarket.impl.SupermarketPackageImpl#getPayment()
		 * @generated
		 */
		EClass PAYMENT = eINSTANCE.getPayment();

		/**
		 * The meta object literal for the '<em><b>Payment ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT__PAYMENT_ID = eINSTANCE.getPayment_PaymentID();

		/**
		 * The meta object literal for the '<em><b>Payment Method</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT__PAYMENT_METHOD = eINSTANCE.getPayment_PaymentMethod();

		/**
		 * The meta object literal for the '<em><b>Amount Paid</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT__AMOUNT_PAID = eINSTANCE.getPayment_AmountPaid();

		/**
		 * The meta object literal for the '<em><b>Salestransaction</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT__SALESTRANSACTION = eINSTANCE.getPayment_Salestransaction();

	}

} //SupermarketPackage
