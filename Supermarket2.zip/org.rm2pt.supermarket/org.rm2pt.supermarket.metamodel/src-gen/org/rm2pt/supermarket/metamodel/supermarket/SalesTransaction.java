/**
 */
package org.rm2pt.supermarket.metamodel.supermarket;

import java.util.Date;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sales Transaction</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTransactionID <em>Transaction ID</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getDate <em>Date</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTotalAmount <em>Total Amount</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getProduct <em>Product</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getCustomer <em>Customer</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getPayment <em>Payment</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction()
 * @model
 * @generated
 */
public interface SalesTransaction extends EObject {
	/**
	 * Returns the value of the '<em><b>Transaction ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transaction ID</em>' attribute.
	 * @see #setTransactionID(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction_TransactionID()
	 * @model
	 * @generated
	 */
	String getTransactionID();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTransactionID <em>Transaction ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transaction ID</em>' attribute.
	 * @see #getTransactionID()
	 * @generated
	 */
	void setTransactionID(String value);

	/**
	 * Returns the value of the '<em><b>Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Date</em>' attribute.
	 * @see #setDate(Date)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction_Date()
	 * @model
	 * @generated
	 */
	Date getDate();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getDate <em>Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Date</em>' attribute.
	 * @see #getDate()
	 * @generated
	 */
	void setDate(Date value);

	/**
	 * Returns the value of the '<em><b>Total Amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Amount</em>' attribute.
	 * @see #setTotalAmount(double)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction_TotalAmount()
	 * @model
	 * @generated
	 */
	double getTotalAmount();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getTotalAmount <em>Total Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Amount</em>' attribute.
	 * @see #getTotalAmount()
	 * @generated
	 */
	void setTotalAmount(double value);

	/**
	 * Returns the value of the '<em><b>Product</b></em>' reference list.
	 * The list contents are of type {@link org.rm2pt.supermarket.metamodel.supermarket.Product}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product</em>' reference list.
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction_Product()
	 * @model
	 * @generated
	 */
	EList<Product> getProduct();

	/**
	 * Returns the value of the '<em><b>Customer</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getSalestransaction <em>Salestransaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer</em>' reference.
	 * @see #setCustomer(Customer)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction_Customer()
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Customer#getSalestransaction
	 * @model opposite="salestransaction"
	 * @generated
	 */
	Customer getCustomer();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getCustomer <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer</em>' reference.
	 * @see #getCustomer()
	 * @generated
	 */
	void setCustomer(Customer value);

	/**
	 * Returns the value of the '<em><b>Payment</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getSalestransaction <em>Salestransaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment</em>' reference.
	 * @see #setPayment(Payment)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getSalesTransaction_Payment()
	 * @see org.rm2pt.supermarket.metamodel.supermarket.Payment#getSalestransaction
	 * @model opposite="salestransaction"
	 * @generated
	 */
	Payment getPayment();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getPayment <em>Payment</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment</em>' reference.
	 * @see #getPayment()
	 * @generated
	 */
	void setPayment(Payment value);

} // SalesTransaction
