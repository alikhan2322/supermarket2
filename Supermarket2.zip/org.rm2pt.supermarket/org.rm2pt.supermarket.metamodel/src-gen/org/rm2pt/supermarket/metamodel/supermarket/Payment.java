/**
 */
package org.rm2pt.supermarket.metamodel.supermarket;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Payment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentID <em>Payment ID</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentMethod <em>Payment Method</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getAmountPaid <em>Amount Paid</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getSalestransaction <em>Salestransaction</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getPayment()
 * @model
 * @generated
 */
public interface Payment extends EObject {
	/**
	 * Returns the value of the '<em><b>Payment ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment ID</em>' attribute.
	 * @see #setPaymentID(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getPayment_PaymentID()
	 * @model
	 * @generated
	 */
	String getPaymentID();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentID <em>Payment ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment ID</em>' attribute.
	 * @see #getPaymentID()
	 * @generated
	 */
	void setPaymentID(String value);

	/**
	 * Returns the value of the '<em><b>Payment Method</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Payment Method</em>' attribute.
	 * @see #setPaymentMethod(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getPayment_PaymentMethod()
	 * @model
	 * @generated
	 */
	String getPaymentMethod();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getPaymentMethod <em>Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Payment Method</em>' attribute.
	 * @see #getPaymentMethod()
	 * @generated
	 */
	void setPaymentMethod(String value);

	/**
	 * Returns the value of the '<em><b>Amount Paid</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Amount Paid</em>' attribute.
	 * @see #setAmountPaid(double)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getPayment_AmountPaid()
	 * @model
	 * @generated
	 */
	double getAmountPaid();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getAmountPaid <em>Amount Paid</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Amount Paid</em>' attribute.
	 * @see #getAmountPaid()
	 * @generated
	 */
	void setAmountPaid(double value);

	/**
	 * Returns the value of the '<em><b>Salestransaction</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getPayment <em>Payment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Salestransaction</em>' reference.
	 * @see #setSalestransaction(SalesTransaction)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getPayment_Salestransaction()
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getPayment
	 * @model opposite="payment"
	 * @generated
	 */
	SalesTransaction getSalestransaction();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Payment#getSalestransaction <em>Salestransaction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Salestransaction</em>' reference.
	 * @see #getSalestransaction()
	 * @generated
	 */
	void setSalestransaction(SalesTransaction value);

} // Payment
