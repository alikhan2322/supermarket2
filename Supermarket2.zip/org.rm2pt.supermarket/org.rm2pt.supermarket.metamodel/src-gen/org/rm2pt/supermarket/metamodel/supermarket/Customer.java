/**
 */
package org.rm2pt.supermarket.metamodel.supermarket;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getCustomerID <em>Customer ID</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getEmail <em>Email</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getSalestransaction <em>Salestransaction</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getCustomer()
 * @model
 * @generated
 */
public interface Customer extends EObject {
	/**
	 * Returns the value of the '<em><b>Customer ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer ID</em>' attribute.
	 * @see #setCustomerID(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getCustomer_CustomerID()
	 * @model
	 * @generated
	 */
	String getCustomerID();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getCustomerID <em>Customer ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer ID</em>' attribute.
	 * @see #getCustomerID()
	 * @generated
	 */
	void setCustomerID(String value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getCustomer_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Email</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Email</em>' attribute.
	 * @see #setEmail(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getCustomer_Email()
	 * @model
	 * @generated
	 */
	String getEmail();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getEmail <em>Email</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Email</em>' attribute.
	 * @see #getEmail()
	 * @generated
	 */
	void setEmail(String value);

	/**
	 * Returns the value of the '<em><b>Salestransaction</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Salestransaction</em>' reference.
	 * @see #setSalestransaction(SalesTransaction)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getCustomer_Salestransaction()
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction#getCustomer
	 * @model opposite="customer"
	 * @generated
	 */
	SalesTransaction getSalestransaction();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Customer#getSalestransaction <em>Salestransaction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Salestransaction</em>' reference.
	 * @see #getSalestransaction()
	 * @generated
	 */
	void setSalestransaction(SalesTransaction value);

} // Customer
