/**
 */
package org.rm2pt.supermarket.metamodel.supermarket.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.rm2pt.supermarket.metamodel.supermarket.Payment;
import org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction;
import org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Payment</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl#getPaymentID <em>Payment ID</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl#getPaymentMethod <em>Payment Method</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl#getAmountPaid <em>Amount Paid</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.PaymentImpl#getSalestransaction <em>Salestransaction</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PaymentImpl extends MinimalEObjectImpl.Container implements Payment {
	/**
	 * The default value of the '{@link #getPaymentID() <em>Payment ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentID()
	 * @generated
	 * @ordered
	 */
	protected static final String PAYMENT_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPaymentID() <em>Payment ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentID()
	 * @generated
	 * @ordered
	 */
	protected String paymentID = PAYMENT_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getPaymentMethod() <em>Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentMethod()
	 * @generated
	 * @ordered
	 */
	protected static final String PAYMENT_METHOD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPaymentMethod() <em>Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentMethod()
	 * @generated
	 * @ordered
	 */
	protected String paymentMethod = PAYMENT_METHOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getAmountPaid() <em>Amount Paid</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAmountPaid()
	 * @generated
	 * @ordered
	 */
	protected static final double AMOUNT_PAID_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getAmountPaid() <em>Amount Paid</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAmountPaid()
	 * @generated
	 * @ordered
	 */
	protected double amountPaid = AMOUNT_PAID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSalestransaction() <em>Salestransaction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSalestransaction()
	 * @generated
	 * @ordered
	 */
	protected SalesTransaction salestransaction;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PaymentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SupermarketPackage.Literals.PAYMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPaymentID() {
		return paymentID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentID(String newPaymentID) {
		String oldPaymentID = paymentID;
		paymentID = newPaymentID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.PAYMENT__PAYMENT_ID, oldPaymentID,
					paymentID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentMethod(String newPaymentMethod) {
		String oldPaymentMethod = paymentMethod;
		paymentMethod = newPaymentMethod;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.PAYMENT__PAYMENT_METHOD,
					oldPaymentMethod, paymentMethod));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getAmountPaid() {
		return amountPaid;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAmountPaid(double newAmountPaid) {
		double oldAmountPaid = amountPaid;
		amountPaid = newAmountPaid;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.PAYMENT__AMOUNT_PAID,
					oldAmountPaid, amountPaid));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SalesTransaction getSalestransaction() {
		if (salestransaction != null && salestransaction.eIsProxy()) {
			InternalEObject oldSalestransaction = (InternalEObject) salestransaction;
			salestransaction = (SalesTransaction) eResolveProxy(oldSalestransaction);
			if (salestransaction != oldSalestransaction) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							SupermarketPackage.PAYMENT__SALESTRANSACTION, oldSalestransaction, salestransaction));
			}
		}
		return salestransaction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SalesTransaction basicGetSalestransaction() {
		return salestransaction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSalestransaction(SalesTransaction newSalestransaction, NotificationChain msgs) {
		SalesTransaction oldSalestransaction = salestransaction;
		salestransaction = newSalestransaction;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SupermarketPackage.PAYMENT__SALESTRANSACTION, oldSalestransaction, newSalestransaction);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSalestransaction(SalesTransaction newSalestransaction) {
		if (newSalestransaction != salestransaction) {
			NotificationChain msgs = null;
			if (salestransaction != null)
				msgs = ((InternalEObject) salestransaction).eInverseRemove(this,
						SupermarketPackage.SALES_TRANSACTION__PAYMENT, SalesTransaction.class, msgs);
			if (newSalestransaction != null)
				msgs = ((InternalEObject) newSalestransaction).eInverseAdd(this,
						SupermarketPackage.SALES_TRANSACTION__PAYMENT, SalesTransaction.class, msgs);
			msgs = basicSetSalestransaction(newSalestransaction, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.PAYMENT__SALESTRANSACTION,
					newSalestransaction, newSalestransaction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SupermarketPackage.PAYMENT__SALESTRANSACTION:
			if (salestransaction != null)
				msgs = ((InternalEObject) salestransaction).eInverseRemove(this,
						SupermarketPackage.SALES_TRANSACTION__PAYMENT, SalesTransaction.class, msgs);
			return basicSetSalestransaction((SalesTransaction) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SupermarketPackage.PAYMENT__SALESTRANSACTION:
			return basicSetSalestransaction(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SupermarketPackage.PAYMENT__PAYMENT_ID:
			return getPaymentID();
		case SupermarketPackage.PAYMENT__PAYMENT_METHOD:
			return getPaymentMethod();
		case SupermarketPackage.PAYMENT__AMOUNT_PAID:
			return getAmountPaid();
		case SupermarketPackage.PAYMENT__SALESTRANSACTION:
			if (resolve)
				return getSalestransaction();
			return basicGetSalestransaction();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SupermarketPackage.PAYMENT__PAYMENT_ID:
			setPaymentID((String) newValue);
			return;
		case SupermarketPackage.PAYMENT__PAYMENT_METHOD:
			setPaymentMethod((String) newValue);
			return;
		case SupermarketPackage.PAYMENT__AMOUNT_PAID:
			setAmountPaid((Double) newValue);
			return;
		case SupermarketPackage.PAYMENT__SALESTRANSACTION:
			setSalestransaction((SalesTransaction) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SupermarketPackage.PAYMENT__PAYMENT_ID:
			setPaymentID(PAYMENT_ID_EDEFAULT);
			return;
		case SupermarketPackage.PAYMENT__PAYMENT_METHOD:
			setPaymentMethod(PAYMENT_METHOD_EDEFAULT);
			return;
		case SupermarketPackage.PAYMENT__AMOUNT_PAID:
			setAmountPaid(AMOUNT_PAID_EDEFAULT);
			return;
		case SupermarketPackage.PAYMENT__SALESTRANSACTION:
			setSalestransaction((SalesTransaction) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SupermarketPackage.PAYMENT__PAYMENT_ID:
			return PAYMENT_ID_EDEFAULT == null ? paymentID != null : !PAYMENT_ID_EDEFAULT.equals(paymentID);
		case SupermarketPackage.PAYMENT__PAYMENT_METHOD:
			return PAYMENT_METHOD_EDEFAULT == null ? paymentMethod != null
					: !PAYMENT_METHOD_EDEFAULT.equals(paymentMethod);
		case SupermarketPackage.PAYMENT__AMOUNT_PAID:
			return amountPaid != AMOUNT_PAID_EDEFAULT;
		case SupermarketPackage.PAYMENT__SALESTRANSACTION:
			return salestransaction != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (paymentID: ");
		result.append(paymentID);
		result.append(", paymentMethod: ");
		result.append(paymentMethod);
		result.append(", amountPaid: ");
		result.append(amountPaid);
		result.append(')');
		return result.toString();
	}

} //PaymentImpl
