/**
 */
package org.rm2pt.supermarket.metamodel.supermarket.impl;

import java.util.Collection;
import java.util.Date;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import org.rm2pt.supermarket.metamodel.supermarket.Customer;
import org.rm2pt.supermarket.metamodel.supermarket.Payment;
import org.rm2pt.supermarket.metamodel.supermarket.Product;
import org.rm2pt.supermarket.metamodel.supermarket.SalesTransaction;
import org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sales Transaction</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl#getTransactionID <em>Transaction ID</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl#getDate <em>Date</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl#getTotalAmount <em>Total Amount</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl#getProduct <em>Product</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl#getCustomer <em>Customer</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.impl.SalesTransactionImpl#getPayment <em>Payment</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SalesTransactionImpl extends MinimalEObjectImpl.Container implements SalesTransaction {
	/**
	 * The default value of the '{@link #getTransactionID() <em>Transaction ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionID()
	 * @generated
	 * @ordered
	 */
	protected static final String TRANSACTION_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTransactionID() <em>Transaction ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionID()
	 * @generated
	 * @ordered
	 */
	protected String transactionID = TRANSACTION_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getDate() <em>Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDate() <em>Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDate()
	 * @generated
	 * @ordered
	 */
	protected Date date = DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getTotalAmount() <em>Total Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalAmount()
	 * @generated
	 * @ordered
	 */
	protected static final double TOTAL_AMOUNT_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getTotalAmount() <em>Total Amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalAmount()
	 * @generated
	 * @ordered
	 */
	protected double totalAmount = TOTAL_AMOUNT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProduct() <em>Product</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProduct()
	 * @generated
	 * @ordered
	 */
	protected EList<Product> product;

	/**
	 * The cached value of the '{@link #getCustomer() <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected Customer customer;

	/**
	 * The cached value of the '{@link #getPayment() <em>Payment</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPayment()
	 * @generated
	 * @ordered
	 */
	protected Payment payment;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SalesTransactionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SupermarketPackage.Literals.SALES_TRANSACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTransactionID() {
		return transactionID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionID(String newTransactionID) {
		String oldTransactionID = transactionID;
		transactionID = newTransactionID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.SALES_TRANSACTION__TRANSACTION_ID,
					oldTransactionID, transactionID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDate(Date newDate) {
		Date oldDate = date;
		date = newDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.SALES_TRANSACTION__DATE, oldDate,
					date));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getTotalAmount() {
		return totalAmount;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalAmount(double newTotalAmount) {
		double oldTotalAmount = totalAmount;
		totalAmount = newTotalAmount;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.SALES_TRANSACTION__TOTAL_AMOUNT,
					oldTotalAmount, totalAmount));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Product> getProduct() {
		if (product == null) {
			product = new EObjectResolvingEList<Product>(Product.class, this,
					SupermarketPackage.SALES_TRANSACTION__PRODUCT);
		}
		return product;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer getCustomer() {
		if (customer != null && customer.eIsProxy()) {
			InternalEObject oldCustomer = (InternalEObject) customer;
			customer = (Customer) eResolveProxy(oldCustomer);
			if (customer != oldCustomer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							SupermarketPackage.SALES_TRANSACTION__CUSTOMER, oldCustomer, customer));
			}
		}
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer basicGetCustomer() {
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCustomer(Customer newCustomer, NotificationChain msgs) {
		Customer oldCustomer = customer;
		customer = newCustomer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SupermarketPackage.SALES_TRANSACTION__CUSTOMER, oldCustomer, newCustomer);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomer(Customer newCustomer) {
		if (newCustomer != customer) {
			NotificationChain msgs = null;
			if (customer != null)
				msgs = ((InternalEObject) customer).eInverseRemove(this, SupermarketPackage.CUSTOMER__SALESTRANSACTION,
						Customer.class, msgs);
			if (newCustomer != null)
				msgs = ((InternalEObject) newCustomer).eInverseAdd(this, SupermarketPackage.CUSTOMER__SALESTRANSACTION,
						Customer.class, msgs);
			msgs = basicSetCustomer(newCustomer, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.SALES_TRANSACTION__CUSTOMER,
					newCustomer, newCustomer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Payment getPayment() {
		if (payment != null && payment.eIsProxy()) {
			InternalEObject oldPayment = (InternalEObject) payment;
			payment = (Payment) eResolveProxy(oldPayment);
			if (payment != oldPayment) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							SupermarketPackage.SALES_TRANSACTION__PAYMENT, oldPayment, payment));
			}
		}
		return payment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Payment basicGetPayment() {
		return payment;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPayment(Payment newPayment, NotificationChain msgs) {
		Payment oldPayment = payment;
		payment = newPayment;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					SupermarketPackage.SALES_TRANSACTION__PAYMENT, oldPayment, newPayment);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPayment(Payment newPayment) {
		if (newPayment != payment) {
			NotificationChain msgs = null;
			if (payment != null)
				msgs = ((InternalEObject) payment).eInverseRemove(this, SupermarketPackage.PAYMENT__SALESTRANSACTION,
						Payment.class, msgs);
			if (newPayment != null)
				msgs = ((InternalEObject) newPayment).eInverseAdd(this, SupermarketPackage.PAYMENT__SALESTRANSACTION,
						Payment.class, msgs);
			msgs = basicSetPayment(newPayment, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SupermarketPackage.SALES_TRANSACTION__PAYMENT,
					newPayment, newPayment));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SupermarketPackage.SALES_TRANSACTION__CUSTOMER:
			if (customer != null)
				msgs = ((InternalEObject) customer).eInverseRemove(this, SupermarketPackage.CUSTOMER__SALESTRANSACTION,
						Customer.class, msgs);
			return basicSetCustomer((Customer) otherEnd, msgs);
		case SupermarketPackage.SALES_TRANSACTION__PAYMENT:
			if (payment != null)
				msgs = ((InternalEObject) payment).eInverseRemove(this, SupermarketPackage.PAYMENT__SALESTRANSACTION,
						Payment.class, msgs);
			return basicSetPayment((Payment) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case SupermarketPackage.SALES_TRANSACTION__CUSTOMER:
			return basicSetCustomer(null, msgs);
		case SupermarketPackage.SALES_TRANSACTION__PAYMENT:
			return basicSetPayment(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case SupermarketPackage.SALES_TRANSACTION__TRANSACTION_ID:
			return getTransactionID();
		case SupermarketPackage.SALES_TRANSACTION__DATE:
			return getDate();
		case SupermarketPackage.SALES_TRANSACTION__TOTAL_AMOUNT:
			return getTotalAmount();
		case SupermarketPackage.SALES_TRANSACTION__PRODUCT:
			return getProduct();
		case SupermarketPackage.SALES_TRANSACTION__CUSTOMER:
			if (resolve)
				return getCustomer();
			return basicGetCustomer();
		case SupermarketPackage.SALES_TRANSACTION__PAYMENT:
			if (resolve)
				return getPayment();
			return basicGetPayment();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case SupermarketPackage.SALES_TRANSACTION__TRANSACTION_ID:
			setTransactionID((String) newValue);
			return;
		case SupermarketPackage.SALES_TRANSACTION__DATE:
			setDate((Date) newValue);
			return;
		case SupermarketPackage.SALES_TRANSACTION__TOTAL_AMOUNT:
			setTotalAmount((Double) newValue);
			return;
		case SupermarketPackage.SALES_TRANSACTION__PRODUCT:
			getProduct().clear();
			getProduct().addAll((Collection<? extends Product>) newValue);
			return;
		case SupermarketPackage.SALES_TRANSACTION__CUSTOMER:
			setCustomer((Customer) newValue);
			return;
		case SupermarketPackage.SALES_TRANSACTION__PAYMENT:
			setPayment((Payment) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case SupermarketPackage.SALES_TRANSACTION__TRANSACTION_ID:
			setTransactionID(TRANSACTION_ID_EDEFAULT);
			return;
		case SupermarketPackage.SALES_TRANSACTION__DATE:
			setDate(DATE_EDEFAULT);
			return;
		case SupermarketPackage.SALES_TRANSACTION__TOTAL_AMOUNT:
			setTotalAmount(TOTAL_AMOUNT_EDEFAULT);
			return;
		case SupermarketPackage.SALES_TRANSACTION__PRODUCT:
			getProduct().clear();
			return;
		case SupermarketPackage.SALES_TRANSACTION__CUSTOMER:
			setCustomer((Customer) null);
			return;
		case SupermarketPackage.SALES_TRANSACTION__PAYMENT:
			setPayment((Payment) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case SupermarketPackage.SALES_TRANSACTION__TRANSACTION_ID:
			return TRANSACTION_ID_EDEFAULT == null ? transactionID != null
					: !TRANSACTION_ID_EDEFAULT.equals(transactionID);
		case SupermarketPackage.SALES_TRANSACTION__DATE:
			return DATE_EDEFAULT == null ? date != null : !DATE_EDEFAULT.equals(date);
		case SupermarketPackage.SALES_TRANSACTION__TOTAL_AMOUNT:
			return totalAmount != TOTAL_AMOUNT_EDEFAULT;
		case SupermarketPackage.SALES_TRANSACTION__PRODUCT:
			return product != null && !product.isEmpty();
		case SupermarketPackage.SALES_TRANSACTION__CUSTOMER:
			return customer != null;
		case SupermarketPackage.SALES_TRANSACTION__PAYMENT:
			return payment != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (transactionID: ");
		result.append(transactionID);
		result.append(", date: ");
		result.append(date);
		result.append(", totalAmount: ");
		result.append(totalAmount);
		result.append(')');
		return result.toString();
	}

} //SalesTransactionImpl
