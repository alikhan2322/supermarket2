/**
 */
package org.rm2pt.supermarket.metamodel.supermarket;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Product</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getPrice <em>Price</em>}</li>
 *   <li>{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getProductCode <em>Product Code</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getProduct()
 * @model abstract="true"
 * @generated
 */
public interface Product extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getProduct_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(double)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getProduct_Price()
	 * @model
	 * @generated
	 */
	double getPrice();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	void setPrice(double value);

	/**
	 * Returns the value of the '<em><b>Product Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Code</em>' attribute.
	 * @see #setProductCode(String)
	 * @see org.rm2pt.supermarket.metamodel.supermarket.SupermarketPackage#getProduct_ProductCode()
	 * @model
	 * @generated
	 */
	String getProductCode();

	/**
	 * Sets the value of the '{@link org.rm2pt.supermarket.metamodel.supermarket.Product#getProductCode <em>Product Code</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Code</em>' attribute.
	 * @see #getProductCode()
	 * @generated
	 */
	void setProductCode(String value);

} // Product
